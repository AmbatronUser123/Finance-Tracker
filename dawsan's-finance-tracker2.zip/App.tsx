import React, { useState, useMemo, useCallback } from 'react';
import { Category, Expense, Goal } from './types';
import { INITIAL_CATEGORIES, INITIAL_GOALS } from './constants';
import { useLocalStorage } from './hooks/useLocalStorage';
import { useToast } from './contexts/ToastContext';
import IncomeInput from './components/IncomeInput';
import CategoryManager from './components/CategoryManager';
import ExpenseLogger from './components/ExpenseLogger';
import Dashboard from './components/Dashboard';
import { Summary } from './components/Summary';
import GoalManager from './components/GoalManager';
import CategoryEditor from './components/CategoryEditor';
import MobileNav from './components/MobileNav';
import { LogoIcon, TrashIcon } from './components/icons';

function App() {
  const [income, setIncome] = useLocalStorage<number>('monthlyIncome', 4000000);
  const [categories, setCategories] = useLocalStorage<Category[]>('budgetCategories', INITIAL_CATEGORIES);
  const [goals, setGoals] = useLocalStorage<Goal[]>('savingGoals', INITIAL_GOALS);
  const { addToast } = useToast();
  
  const [mobileView, setMobileView] = useState('dashboard');
  const [isCategoryModalOpen, setCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  const handleIncomeChange = useCallback((newIncome: number) => {
    setIncome(Math.max(0, newIncome));
  }, [setIncome]);

  const handleAllocationChange = useCallback((categoryId: string, newAllocation: number) => {
    setCategories(prevCategories =>
      prevCategories.map(cat =>
        cat.id === categoryId ? { ...cat, allocation: Math.max(0, newAllocation) } : cat
      )
    );
  }, [setCategories]);

  const handleAddExpense = useCallback((expense: Omit<Expense, 'id'>) => {
    const newExpense: Expense = {
      ...expense,
      id: `exp-${new Date().getTime()}`,
    };
    setCategories(prevCategories =>
      prevCategories.map(cat =>
        cat.id === expense.categoryId
          ? { ...cat, expenses: [...cat.expenses, newExpense] }
          : cat
      )
    );
    addToast({ message: 'Expense logged successfully!', type: 'success' });
  }, [setCategories, addToast]);
  
  const handleAddGoal = useCallback((goal: Omit<Goal, 'id' | 'currentAmount'>) => {
    const newGoal: Goal = {
      ...goal,
      id: `goal-${new Date().getTime()}`,
      currentAmount: 0,
    };
    setGoals(prevGoals => [...prevGoals, newGoal]);
    addToast({ message: 'New goal created!', type: 'success' });
  }, [setGoals, addToast]);

  const handleAllocateToGoal = useCallback((goalId: string, amount: number) => {
    setGoals(prevGoals =>
      prevGoals.map(g =>
        g.id === goalId ? { ...g, currentAmount: g.currentAmount + amount } : g
      )
    );
    addToast({ message: `Funds added to goal!`, type: 'success' });
  }, [setGoals, addToast]);
  
  const handleDeleteGoal = useCallback((goalId: string) => {
     setGoals(prevGoals => prevGoals.filter(g => g.id !== goalId));
     addToast({ message: 'Goal removed.', type: 'info' });
  }, [setGoals, addToast]);

  const handleResetData = useCallback(() => {
    if(window.confirm('Are you sure you want to reset all your data? This cannot be undone.')) {
        setIncome(4000000);
        setCategories(INITIAL_CATEGORIES);
        setGoals(INITIAL_GOALS);
        addToast({ message: 'All data has been reset.', type: 'info' });
    }
  }, [setIncome, setCategories, setGoals, addToast]);
  
  const handleClearExpenses = useCallback((categoryId: string) => {
     setCategories(prevCategories =>
      prevCategories.map(cat =>
        cat.id === categoryId
          ? { ...cat, expenses: [] }
          : cat
      )
    );
    addToast({ message: 'Expenses cleared for category.', type: 'info' });
  }, [setCategories, addToast]);

  // --- Category CRUD ---
  const handleOpenCategoryModal = (category: Category | null) => {
    setEditingCategory(category);
    setCategoryModalOpen(true);
  };
  
  const handleCloseCategoryModal = () => {
    setEditingCategory(null);
    setCategoryModalOpen(false);
  };

  const handleSaveCategory = (categoryData: Omit<Category, 'id' | 'expenses'> & { id?: string }) => {
    if (categoryData.id) { // Update existing
      setCategories(prev => prev.map(cat => cat.id === categoryData.id ? { ...cat, ...categoryData } : cat));
      addToast({ message: `Category "${categoryData.name}" updated.`, type: 'success' });
    } else { // Add new
      const newCategory: Category = {
        ...categoryData,
        id: `cat-${new Date().getTime()}`,
        expenses: [],
      };
      setCategories(prev => [...prev, newCategory]);
      addToast({ message: `Category "${categoryData.name}" created.`, type: 'success' });
    }
    handleCloseCategoryModal();
  };
  
  const handleDeleteCategory = (categoryId: string) => {
    const categoryToDelete = categories.find(c => c.id === categoryId);
    if (!categoryToDelete) return;

    if (categoryToDelete.expenses.length > 0) {
        addToast({ message: 'Cannot delete category with existing expenses. Please clear them first.', type: 'error'});
        return;
    }
    if (window.confirm(`Are you sure you want to delete the "${categoryToDelete.name}" category?`)) {
        setCategories(prev => prev.filter(c => c.id !== categoryId));
        addToast({ message: `Category "${categoryToDelete.name}" deleted.`, type: 'info' });
    }
  };

  const { totalSpent, totalAllocation, totalAllocatedToGoals } = useMemo(() => {
    const spent = categories.reduce((sum, cat) => {
      return sum + cat.expenses.reduce((catSum, exp) => catSum + exp.amount, 0);
    }, 0);
    const allocation = categories.reduce((sum, cat) => sum + cat.allocation, 0);
    const allocatedToGoals = goals.reduce((sum, goal) => sum + goal.currentAmount, 0);
    return { totalSpent: spent, totalAllocation: allocation, totalAllocatedToGoals: allocatedToGoals };
  }, [categories, goals]);

  const totalBudget = income;
  const totalRemaining = totalBudget - totalSpent - totalAllocatedToGoals;
  const isBudgetValid = totalAllocation === 100;
  const availableToSave = totalBudget - totalSpent;

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <header className="mb-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <LogoIcon className="w-10 h-10 text-indigo-600" />
            <h1 className="text-2xl sm:text-3xl text-slate-800 tracking-tight">Dawsan's Finance Tracker</h1>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={handleResetData}
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-rose-600 rounded-lg shadow-sm hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-50 focus:ring-rose-500"
            >
              <TrashIcon className="w-4 h-4" />
              Reset All Data
            </button>
          </div>
        </header>

        <main className="relative">
            {/* Desktop View */}
            <div className="hidden lg:grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
              <div className="lg:col-span-1 space-y-6">
                  <Summary
                    totalBudget={totalBudget}
                    totalSpent={totalSpent}
                    totalRemaining={totalRemaining}
                    totalAllocatedToGoals={totalAllocatedToGoals}
                    categories={categories}
                  />
                  <IncomeInput income={income} onIncomeChange={handleIncomeChange} />
                  <ExpenseLogger
                    categories={categories}
                    onAddExpense={handleAddExpense}
                    isAddDisabled={!isBudgetValid}
                  />
              </div>
              <div className="lg:col-span-2 space-y-6">
                <CategoryManager
                  categories={categories}
                  onAllocationChange={handleAllocationChange}
                  totalAllocation={totalAllocation}
                  onOpenModal={handleOpenCategoryModal}
                  onDeleteCategory={handleDeleteCategory}
                />
                <GoalManager
                  goals={goals}
                  onAddGoal={handleAddGoal}
                  onAllocateToGoal={handleAllocateToGoal}
                  onDeleteGoal={handleDeleteGoal}
                  availableFunds={availableToSave}
                />
                <Dashboard 
                  income={income} 
                  categories={categories} 
                  onClearExpenses={handleClearExpenses}
                />
              </div>
            </div>

            {/* Mobile View */}
            <div className="lg:hidden pb-24 space-y-6">
                {mobileView === 'dashboard' && (
                  <>
                    <Summary
                      totalBudget={totalBudget}
                      totalSpent={totalSpent}
                      totalRemaining={totalRemaining}
                      totalAllocatedToGoals={totalAllocatedToGoals}
                      categories={categories}
                    />
                    <Dashboard 
                        income={income} 
                        categories={categories} 
                        onClearExpenses={handleClearExpenses}
                    />
                  </>
                )}
                {mobileView === 'log' && (
                    <ExpenseLogger
                        categories={categories}
                        onAddExpense={handleAddExpense}
                        isAddDisabled={!isBudgetValid}
                    />
                )}
                 {mobileView === 'budgets' && (
                    <>
                        <IncomeInput income={income} onIncomeChange={handleIncomeChange} />
                        <CategoryManager
                            categories={categories}
                            onAllocationChange={handleAllocationChange}
                            totalAllocation={totalAllocation}
                            onOpenModal={handleOpenCategoryModal}
                            onDeleteCategory={handleDeleteCategory}
                        />
                    </>
                 )}
                 {mobileView === 'goals' && (
                     <GoalManager
                        goals={goals}
                        onAddGoal={handleAddGoal}
                        onAllocateToGoal={handleAllocateToGoal}
                        onDeleteGoal={handleDeleteGoal}
                        availableFunds={availableToSave}
                     />
                 )}
            </div>
            
            <MobileNav activeView={mobileView} setActiveView={setMobileView} />
        </main>
      </div>
      
      {isCategoryModalOpen && (
        <CategoryEditor 
            onClose={handleCloseCategoryModal}
            onSave={handleSaveCategory}
            categoryToEdit={editingCategory}
        />
      )}
    </div>
  );
}

export default App;
